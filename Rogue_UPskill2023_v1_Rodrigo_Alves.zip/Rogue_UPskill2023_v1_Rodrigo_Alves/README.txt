O movimento do herói é feito com as setas direcionais.
Para atirar uma bola de fogo, pressione a barra de espaço. Esta será atirada na última direção que o herói se moveu.
Para usar ou largar os itens, pressiona as teclas 1 a 3 para interagir com os itens na ordem que estão no inventário.
Para consultar o teu score, pressiona a tecla i.